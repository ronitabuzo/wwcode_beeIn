//
//  ViewController.h
//  TextInputAnalysis
//
//  Created by Samana Tahir on 28/07/2018.
//  Copyright © 2018 Samana Tahir. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITextFieldDelegate>
{
    NSMutableArray *employeeInfoArray;
}
@property (strong, nonatomic) IBOutlet UITextField *employeeID;
@property (strong, nonatomic) IBOutlet UITextField *ProblemStatement;
@property (strong, nonatomic) IBOutlet UISegmentedControl *anoymonoususer;
@property (strong, nonatomic) IBOutlet UISwitch *isAnonymousUser;
@property (strong, nonatomic) IBOutlet UITextView *problemArea;

@end

