//
//  AppDelegate.h
//  TextInputAnalysis
//
//  Created by Samana Tahir on 28/07/2018.
//  Copyright © 2018 Samana Tahir. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

