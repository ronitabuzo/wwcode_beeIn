//
//  ViewController.m
//  TextInputAnalysis
//
//  Created by Samana Tahir on 28/07/2018.
//  Copyright © 2018 Samana Tahir. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
- (void)viewDidLoad {
    employeeInfoArray  = [[NSMutableArray alloc]initWithCapacity:0];
    [[self.problemArea layer] setBorderColor:[[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0] CGColor]];
    [[self.problemArea layer] setBorderWidth:1];
    [[self.problemArea layer] setCornerRadius:10];
    [super viewDidLoad];
    self.ProblemStatement.delegate = self;
    // Do any additional setup after loading the view, typically from a nib.
    

}


    

- (IBAction)btnClicked:(id)sender {
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"MM/dd/yyyy"];
    NSString *isAnUser;
    NSLog(@"%@",[dateFormatter stringFromDate:[NSDate date]]);
    NSLog(@"BUTTON CLICKED");
    
    NSLog(@"%ld",(long)self.isAnonymousUser.isOn);
        NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithCapacity:0];
        [dict setValue:self.employeeID.text forKey:@"EMPID"];
        [dict setValue:self.problemArea.text forKey:@"PROB"];
       if(self.isAnonymousUser.isOn)
       {
           isAnUser =@"TRUE";
       }
       else{
           isAnUser =@"FALSE";
       }
        [dict setValue:isAnUser forKey:@"isAUser"];
         [dict setValue:[dateFormatter stringFromDate:[NSDate date]] forKey:@"Time"];
        [employeeInfoArray addObject:dict];
        

    
    [self createCSV];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)createCSV
{
    NSMutableString *csvString = [[NSMutableString alloc]initWithCapacity:0];
       NSString *filecontents = [NSString stringWithContentsOfFile:@"/Users/samanatahir/Employee_Comments.csv"encoding:NSUTF8StringEncoding error:nil];
    [csvString appendString:filecontents];

    
    for (NSDictionary *dct in employeeInfoArray)
    {
        [csvString appendString:[NSString stringWithFormat:@"%@, %@,%@, %@\n",[dct valueForKey:@"EMPID"],[dct valueForKey:@"PROB"],[dct valueForKey:@"isAUser"],[dct valueForKey:@"Time"]]];
    }
    
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    documentsDirectory = @"/Users/samanatahir/";
    NSString *filePath = [NSString stringWithFormat:@"%@/%@", documentsDirectory, @"Employee_Comments.csv"];
    NSLog(@"%@",filePath);
    [csvString writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
   

}



@end
